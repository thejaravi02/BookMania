# BookMania - Voice Assistant with GUI and Book Summary

import pyttsx3
import speech_recognition as sr
import PyPDF2
import os
import tkinter as tk
from tkinter import messagebox, filedialog
from transformers import pipeline

engine = pyttsx3.init()
engine.setProperty('rate', 150)
engine.setProperty('volume', 1.0)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

def speak(text):
    print("BookMania:", text)
    engine.say(text)
    engine.runAndWait()

recognizer = sr.Recognizer()
def listen():
    with sr.Microphone() as source:
        print("Listening...")
        audio = recognizer.listen(source)
        try:
            command = recognizer.recognize_google(audio)
            print("You said:", command)
            return command.lower()
        except sr.UnknownValueError:
            speak("Sorry, I didn't understand. Please repeat.")
            return ""

books = {}
def add_book():
    filepath = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf")])
    if filepath:
        name = os.path.basename(filepath).split('.')[0].lower()
        books[name] = filepath
        messagebox.showinfo("Book Added", f"{name} added successfully!")

def read_page(book_name, page_num):
    if book_name not in books:
        speak("Sorry, I couldn't find that book.")
        return
    try:
        with open(books[book_name], 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            if page_num < 0 or page_num >= len(reader.pages):
                speak("Invalid page number.")
                return
            text = reader.pages[page_num].extract_text()
            if text:
                speak(text)
            else:
                speak("This page has no readable text.")
    except:
        speak("Error reading the book.")

summarizer = pipeline("summarization")
def summarize_book(book_name):
    if book_name not in books:
        speak("Book not found.")
        return
    try:
        with open(books[book_name], 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ""
            for i in range(min(3, len(reader.pages))):
                text += reader.pages[i].extract_text()
            if not text.strip():
                speak("Book is empty or not readable.")
                return
            summary = summarizer(text[:1000], max_length=150, min_length=40, do_sample=False)[0]['summary_text']
            speak("Here is the summary:")
            speak(summary)
    except Exception as e:
        speak("Unable to summarize the book.")

def handle_command(command):
    if "wake up bookmania" in command:
        speak("Hi there! This is BookMania. How may I help you?")
    elif "read" in command and "page" in command:
        words = command.split()
        page_num = -1
        for i, word in enumerate(words):
            if word == "page" and i+1 < len(words):
                try:
                    page_num = int(words[i+1])
                except:
                    pass
        for book in books:
            if book in command:
                read_page(book, page_num)
                return
        speak("Book not found in your command.")
    elif "summary" in command:
        for book in books:
            if book in command:
                summarize_book(book)
                return
        speak("Please specify a valid book for summary.")
    elif "voice off" in command:
        speak("Turning off voice interaction.")
        root.destroy()
    elif "voice on" in command:
        speak("Voice is already on.")
    else:
        speak("I couldn't understand. Do you want me to read or summarize a book?")

root = tk.Tk()
root.title("BookMania - Voice Assistant")
root.geometry("500x300")
root.config(bg="#d3e0ea")

title = tk.Label(root, text="BookMania", font=("Arial", 24, "bold"), bg="#d3e0ea")
title.pack(pady=20)

mic_button = tk.Button(root, text="🎙 Voice Command", font=("Arial", 14), command=lambda: handle_command(listen()))
mic_button.pack(pady=10)

add_book_btn = tk.Button(root, text="➕ Add Book", font=("Arial", 12), command=add_book)
add_book_btn.pack(pady=5)

def startup():
    speak("Hi there! This is BookMania. How may I help you?")

root.after(1000, startup)
root.mainloop()
