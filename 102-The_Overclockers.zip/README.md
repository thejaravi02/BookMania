# BookMania - Voice Assistant for Visually Impaired

## Features
- Voice-controlled assistant
- Summarize and read PDF books
- Simple and intuitive interface
- Commands like "Wake Up BookMania", "Read page 5 of bookname", "Summary of bookname"

## How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python bookmania.py
   ```
